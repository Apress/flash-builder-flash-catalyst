<?php
echo file_get_contents($_POST["url"]);
?>